Eaxy_Group - Proyecto completo (PWA + Flask backend)
Instrucciones:
1) Subir carpeta Eaxy_Group a GitHub.
2) En Render, crear Web Service apuntando a backend folder, instalar requirements and start app.
3) Alternativamente iniciar backend locally: python backend/app.py and open frontend/index.html or visit http://localhost:5000/
Users: dani / 1319, camilo / 3852
